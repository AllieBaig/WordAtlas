
// modules.js
export { getErrorLog, clearErrorLog, initErrorLogging } from './utils/errorHandler.js';
export { renderErrorLog } from './utils/errorLog.js';
