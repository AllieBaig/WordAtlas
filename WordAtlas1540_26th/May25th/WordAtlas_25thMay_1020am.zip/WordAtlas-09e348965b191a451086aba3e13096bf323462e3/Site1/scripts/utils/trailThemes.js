

export const trailThemes = [
  { name: "Sky Kingdom", description: "A world above the clouds." },
  { name: "Nordic Wilderness", description: "Cold lands, snow, and myths." },
  { name: "Jungle Secrets", description: "Tropical mystery and creatures." },
  { name: "Ancient Ruins", description: "Timeworn places filled with legend." },
];

