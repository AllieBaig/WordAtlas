

startTimer({ seconds, onTick, onEnd }) // begins countdown and calls hooks
stopTimer()                            // stops any running timer
resetTimer()                           // stops and clears timer

